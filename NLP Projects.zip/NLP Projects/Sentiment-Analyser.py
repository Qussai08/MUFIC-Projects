import nltk.classify.util
from nltk.classify import NaiveBayesClassifier
import csv


def extract_features(review):
    word_list = review.split()
    return dict([(word,True) for word in word_list])


if __name__ == '__main__':
    csv_file = open(
        '/media/muhammad/disk/projects/Athena/athena/assistant/modules/hotelsReviews.csv')
    csv_reader = csv.reader(csv_file, delimiter=',')
    dataFile = []
    goodReviews = []
    neutralReviews = []
    badReviews = []
    for index, row in enumerate(csv_reader):
        if index != 0:
            dataFile.append(row)
            if row[1] == '1':
                goodReviews.append(row)
            elif row[1] == '0':
                neutralReviews.append(row)
            elif row[1] == '-1':
                badReviews.append(row)

    # print(len(goodReviews))
    # print(extract_features(goodReviews[1][0]))

    # separate reviews into positive , neutral and negative features
    features_positive = [(extract_features(review[0]), 'Positive')
                         for review in goodReviews]
    features_negative = [(extract_features(review[0]), 'Negative')
                         for review in badReviews]
    features_neutral = [(extract_features(review[0]), 'Neutral')
                        for review in neutralReviews]

    # print(features_negative)

    # Split the dataset into training and testing datasets (80/20)
    threshold_factor = 0.8
    threshold_positive = int(threshold_factor * len(features_positive))
    threshold_negative = int(threshold_factor * len(features_negative))
    threshold_neutral = int(threshold_factor * len(features_neutral))

    # Extract the features
    features_train = features_positive[:threshold_positive] + \
        features_negative[:threshold_negative] + \
		features_neutral[:threshold_neutral]

    features_test = features_positive[threshold_positive:] + \
        features_negative[threshold_negative:] + \
		features_neutral[threshold_neutral:]

    print("Number of training data observations:", len(features_train))
    print("Number of test data observations:", len(features_test))

    # use a Naive Bayes classifier and train it
    classifier = NaiveBayesClassifier.train(features_train)
    print("Accuracy of the classifier:",nltk.classify.util.accuracy(classifier, features_test))

    # the most informative words that it obtained
    for item in classifier.most_informative_features()[:20]:
        print(item[0])

    # Sample input reviews
    input_reviews = [
        "إن هذا الفندق رائع",
        "خدمة الفندق سيئة للغاية",
        "المناظر الطبيعية التي يطل عليها الفندق جميلة وهادئة",
        "الفندق جيد ولكن خدمة العملاء سيئة"
    ]
    # Run the classifier on those input
    print("Predictions:")
    for review in input_reviews:
        print("Review:", review)
        probdist = classifier.prob_classify(extract_features(review))
        predected_sentiment = probdist.max()
        print("Predicted sentiment:", predected_sentiment)
        print("Probability:", round(probdist.prob(predected_sentiment), 2))