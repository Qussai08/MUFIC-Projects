import Stemmer
import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="",
  database ="nlp"
)

mycursor = mydb.cursor()

#mycursor.execute("CREATE DATABASE nlp CHARACTER SET utf8 COLLATE utf8_general_ci;")
mycursor.execute("CREATE TABLE statment (word VARCHAR(255), type VARCHAR(255))")


sql = "INSERT INTO statment (word, type) VALUES (%s, %s)"

statement = input('Enter Arabic Word')
listOfWords = Stemmer.tokenizeArabic(statement)

stems = Stemmer.stemArabic(listOfWords)

for index , stem in enumerate(stems) :
    val = (stem, listOfWords[index])
    mycursor.execute(sql, val)

mydb.commit()


mycursor.execute("SELECT * FROM statment")

myresult = mycursor.fetchall()

for x in myresult:
  print(x)

print(mycursor.rowcount, "record inserted.")



'''
utf8Name ="SET NAMES 'utf8'"
utf8Char = "SET CHARACTER SET utf8"
mycursor.execute(utf8Name)

mycursor.execute(utf8Char)
'''
