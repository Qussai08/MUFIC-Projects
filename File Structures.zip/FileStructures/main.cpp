#include <fstream>
#include <iostream>

using namespace std;

int main()
{
    char ch ;
    fstream file ;

    file.open("test.txt", ios::in|ios::out);
    file.unsetf(ios::skipws);
    file.seekg(0,ios::beg);
    file >> ch ;
    cout << ch ;
    file >> ch ;
    cout << ch ;
    file.seekg(5 , ios::cur);
    file >> ch ;
    cout << ch ;
    file >> ch ;
    cout << ch ;
    file.close();

    file.open("test.txt" ,ios::in);
    file.seekg(3,ios::cur);
    file >> ch ;
    cout << ch ;
    return 0;
}
