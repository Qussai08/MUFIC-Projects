/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multimedia_tasks;

import java.util.Scanner;

/**
 *
 * @author OLA
 */
public class run_length {

    public static void main(String[] args) {
        System.out.println("Enter Code You need to compress:");
        Scanner s = new Scanner(System.in);
        String str = s.nextLine();
        String value=encode_string(str);
        System.out.println("The code is "+value);

    }

    public static String encode_string(String code) {

        String outp_string = "";
        int count = 1;
        for (int i = 0; i < code.length(); i++) {
            if (i + 1 < code.length() && code.charAt(i) == code.charAt(i + 1)) {
                count++;
            } else {
                outp_string += "(" + Character.toString(code.charAt(i)) + " , " + Integer.toString(count) + ")";
                count = 1;
            }

        }
        return outp_string;
    }
}
