
import tkMessageBox
import ttk
from Tkinter import *
import os
import math


class Window():
      # window creation
               root = Tk()
               label_frame = ttk.Frame(root)
               button_frame = ttk.Frame(root)
               label = Label()
               button = list()
               def __init__(self):
                   self.add_weidget()
               def add_weidget(self):
                      self.root.minsize(200, 200)
                      self.root.title('Shanon')

                                     #label that contain labels and entry fields
                      self.label_frame.config(height=20)
                      self.label_frame.config(relief=RIDGE)
                      self.label_frame.config(width=200, height=100)
                      self.label_frame.pack(padx=5, pady=5, fill="both")

                                   #buttons frame that contain all buttons
                      self.button_frame.config(height=50)
                      self.button_frame.config(relief=RIDGE)
                      self.button_frame.config(width=200, height=50)
                      self.button_frame.pack(padx=5, pady=5, side=BOTTOM)


                                   #string x
                      self.L1 = Label(self.label_frame, text="Text   ")
                      self.L1.config(width=20)
                      self.L1.grid(row=0,column=0,padx=5, pady=5)
                                  #string x
                      self.x1 = Entry(self.label_frame, bd =5)
                      self.x1.config(width=100)
                      self.x1.grid(row=0,column=1,padx=5,pady=5)




                      for i in range(2):
                                  self.button.append(ttk.Button(self.button_frame))
                      count = 0
                      for i in range(2):
                              self.button[count].grid(row=0, column=i, padx=5, pady=5)
                              count += 1


                                   #buttons characteristics
                      self.button[0].config(text="Apply", width=20 )
                      self.button[1].config(text="exit", width=20)

                                  #buttons action
                      self.button[0].config(command=lambda :self.generate())
                      self.button[1].config(command=self.root.destroy)
                      self.root.mainloop()





               def generate(self):
                      global code
                      try:
                               s=self.x1.get()
                               frequency=[]
                               alpha=[]
                               for i in range (len(s)):
                                   count=0
                                   if(s[i] not in alpha):
                                       alpha.append(s[i])
                                       for j in range(len(s)):
                                           if(s[i]==s[j]):

                                             count=count+1

                                       frequency.append(count)

                               list_alpha_freq=[]
                               for i in range(len(frequency)):
                                   list_alpha_freq.append([frequency[i],alpha[i],''])

                               frequency_list=sorted(list_alpha_freq,key=lambda a:a[0], reverse=True)
                               print (frequency_list)
                               self.shanon_code(frequency_list)

                               with open('C:\\Users\\hodam\\Desktop\\123.txt', 'w') as fil:
                                   for i in range(len(frequency_list)):
                                               fil.write(frequency_list[i][1]+' = '+ frequency_list[i][2]+' \n')
                                   y=''
                                   for i in range(len(s)):
                                       for j in range(len(frequency_list)):
                                              if(s[i]==frequency_list[j][1]):
                                                  y=y+frequency_list[j][2]+'||'

                                   fil.write(y)
                                   fil.close()
                               os.system('C:\\Users\\hodam\\Desktop\\123.txt')
                      except:
                               tkMessageBox.showerror(title="Error", message="enter text first")

               def divid(self,a):
                      global sum_left
                      global sum_right
                      possible_divid=[]
                      for i in range(len(a)):
                          sum_left=0
                          sum_right=0
                          for x in range(i):
                              sum_left =sum_left+a[x][0]
                          for y in range(i,len(a)):
                              sum_right =sum_right+a[y][0]
                          difference=math.fabs(sum_right-sum_left)
                          possible_divid.append((i,difference))
                      divid_possible=sorted(possible_divid,key=lambda x:x[1])
                      print (divid_possible)
                      return divid_possible[0][0]


               def shanon_code(self,a):

                   possible_divid_position=self.divid(a)
                   for x in range (possible_divid_position):
                       a[x][2] +='0'
                   for y in range(possible_divid_position,len(a)):
                       a[y][2] +='1'
                   if (possible_divid_position>=2):
                         self.shanon_code(a[:possible_divid_position])
                   if (len(a)-possible_divid_position>=2):
                         self.shanon_code(a[possible_divid_position:])
                   return a

def main():
    g = Window()


if __name__ == '__main__':
    main()








