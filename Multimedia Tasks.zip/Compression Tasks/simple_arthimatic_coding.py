
import tkMessageBox
import ttk
from Tkinter import *
import os



class Window():
      # window creation
           root = Tk()
           label_frame = ttk.Frame(root)
           button_frame = ttk.Frame(root)
           label = Label()
           button = list()
           def __init__(self):
                   self.add_weidget()
           def add_weidget(self):
                     self.root.minsize(200, 200)
                     self.root.title('Simple Arithmetic Coding')

                                    #label that contain labels and entry fields
                     self.label_frame.config(height=20)
                     self.label_frame.config(relief=RIDGE)
                     self.label_frame.config(width=200, height=100)
                     self.label_frame.pack(padx=5, pady=5, fill="both")

                                  #buttons frame that contain all buttons
                     self.button_frame.config(height=50)
                     self.button_frame.config(relief=RIDGE)
                     self.button_frame.config(width=200, height=50)
                     self.button_frame.pack(padx=5, pady=5, side=BOTTOM)


                                  #string x
                     self.L1 = Label(self.label_frame, text="Text   ")
                     self.L1.config(width=20)
                     self.L1.grid(row=0,column=0,padx=5, pady=5)
                                 #string x
                     self.x1 = Entry(self.label_frame, bd =5)
                     self.x1.config(width=100)
                     self.x1.grid(row=0,column=1,padx=5,pady=5)




                     for i in range(2):
                                 self.button.append(ttk.Button(self.button_frame))
                     count = 0
                     for i in range(2):
                             self.button[count].grid(row=0, column=i, padx=5, pady=5)
                             count += 1


                                  #buttons characteristics
                     self.button[0].config(text="Apply", width=20 )
                     self.button[1].config(text="exit", width=20)

                                 #buttons action
                     self.button[0].config(command=lambda :self.generate())
                     self.button[1].config(command=self.root.destroy)
                     self.root.mainloop()




           def generate(self):
                  global list_alpha_freq
                  try:
                           s=self.x1.get()
                           frequency=[]
                           alpha=[]

                           for i in range (len(s)):
                               count=0
                               if(s[i] not in alpha):
                                   alpha.append(s[i])
                                   for j in range(len(s)):
                                       if(s[i]==s[j]):

                                         count=count+1

                                   frequency.append(float(count)/len(s))

                           list_alpha_freq=[]
                           x=[]
                           for i in range(len(frequency)):
                               list_alpha_freq.append([frequency[i],0,alpha[i]])
                               x.append([frequency[i],0,alpha[i]])
                           x=sorted(x,key=lambda  a:a[2])
                           frequency_list=sorted(list_alpha_freq,key=lambda a:a[2])

                           temp=0
                           for i in range(len(frequency_list)):
                               temp1=frequency_list[i][0]
                               frequency_list[i][0]=temp
                               frequency_list[i][1]=temp1+temp
                               temp=frequency_list[i][1]

                           for i in range(len(frequency_list)):
                               if(list_alpha_freq[i][2]==frequency_list[i][2]):
                                   list_alpha_freq[i][0]=frequency_list[i][0]
                                   list_alpha_freq[i][1]=frequency_list[i][1]
                           with open('C:\Users\sh3la\Desktop\123.txt', 'w') as fil:
                               y=''
                               output=self.generate_final_code(list_alpha_freq[0],x,s)
                               for i in range(len(output)):
                                   y +=str(output[i])+' , '
                               fil.write(y)
                               fil.close()
                           os.system('C:\Users\sh3la\Desktop\123.txt')
                  except:
                         tkMessageBox.showerror(title="Error", message="enter text first")

           def generate_final_code(self,a,b,s):
               global final
               list_list=[]
               start=a[0]
               temp=start
               end  =a[1]
               print a[2]
               print b

               range_interval=float(end-start)
               for i in range(len(b)):
                   print temp
                   list_list.append([temp,temp+b[i][0]*range_interval,a[2]+b[i][2]])
                   temp=temp+b[i][0]*range_interval
               print list_list
               print len(list_list[0][2])
               print len(s)
               if(len(list_list[0][2])==len(s)):
                   for i in range(len(list_list)):
                     if(list_list[i][2] == s):
                       final =list_list[i]
               else:
                 for i in range(len(list_list)):
                   if(list_list[i][2] == s[:len(list_list[i][2])]):
                       self.generate_final_code(list_list[i],b,s)

               return final





def main():
    g = Window()


if __name__ == '__main__':
    main()