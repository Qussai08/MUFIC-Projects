import numpy as np
import cv2


img = cv2.imread('C:\\Users\\hodam\\Desktop\\Multimedia Tasks\\test.jpeg' , 0)
dither = cv2.imread('C:\\Users\\hodam\\Desktop\\Multimedia Tasks\\test.jpeg' , 0)

rows , cols = dither.shape

for i in range(rows):
    for j in range(cols):
        x = dither[i][j]
        if dither[i][j] < 128:
            dither[i][j] = 0
        else :
            dither[i][j] = 255

cv2.imshow('image' , img)
cv2.imshow('Floyd' , dither)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite('C:\\Users\\hodam\\Desktop\\Multimedia Tasks\\threshold1.png' , dither)