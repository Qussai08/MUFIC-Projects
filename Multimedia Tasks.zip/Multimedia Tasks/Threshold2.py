import numpy as np
import cv2


img = cv2.imread('C:\\Users\\hodam\\Desktop\\Multimedia Tasks\\test.jpeg' , 0)
dither = cv2.imread('C:\\Users\\hodam\\Desktop\\Multimedia Tasks\\test.jpeg' , 0)

rows , cols = dither.shape

avg = 0

for i in range(rows):
	for j in range(cols):
		avg = avg + dither[i][j]

avg = avg / (rows*cols)

for i in range(rows):
    for j in range(cols):
        x = dither[i][j]
        if dither[i][j] < avg:
            dither[i][j] = 0
        else :
            dither[i][j] = 255

cv2.imshow('image' , img)
cv2.imshow('Floyd' , dither)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite('C:\\Users\\hodam\\Desktop\\Multimedia Tasks\\threshold2.png' , dither)