import numpy as np
import cv2

alpha = cv2.imread('D:\\PyCharmProjects\\MultimdiaTasks\\alpha.jpg')
foreground = cv2.imread('D:\\PyCharmProjects\\MultimdiaTasks\\foreground.jpg')
background = cv2.imread('D:\\PyCharmProjects\\MultimdiaTasks\\background.jpg')

alpha = alpha.astype(float)/255

resultAlpha = (alpha*foreground) + ((1-alpha)*background)
# to keep instensity between 0 and 1 for alpha mask
cv2.imshow('image',resultAlpha/255)
cv2.waitKey(0)
cv2.destroyAllWindows()

#to write an image
cv2.imwrite('D:\\PyCharmProjects\\MultimdiaTasks\\result.png',resultAlpha)

