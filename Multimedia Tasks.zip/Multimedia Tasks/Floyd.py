import numpy as np
import cv2


img = cv2.imread('C:\\Users\\hodam\\Desktop\\Multimedia Tasks\\test.jpeg' , 0)
dither = cv2.imread('C:\\Users\\hodam\\Desktop\\Multimedia Tasks\\test.jpeg' , 0)

rows , cols = dither.shape

alpha = 7/16
beta = 3/16
gama = 5/16
delta = 1/16

for i in range(rows):
    for j in range(cols):
        x = dither[i][j]
        if dither[i][j] < 128:
            dither[i][j] = 0
        else :
            dither[i][j] = 255

        error = np.subtract(x , dither[i][j])

        if j < cols - 1:
            dither[i][j+1] = dither[i][j+1] + alpha*error
        if i < rows - 1:
            if j > 0:
                dither[i+1][j-1] = dither[i+1][j-1] + beta*error
            if j < rows - 1:
                dither[i+1][j+1] = dither[i+1][j+1] + delta*error

            dither[i+1][j] = dither[i+1][j] + gama*error

cv2.imshow('image' , img)
cv2.imshow('Floyd' , dither)
cv2.waitKey(0)
cv2.destroyAllWindows()
