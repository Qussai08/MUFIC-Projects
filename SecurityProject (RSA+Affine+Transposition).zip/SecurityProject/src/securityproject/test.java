/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package securityproject;


/**
 *
 * @author VGA!Sys
 */
public class test {
//    tNum.setDisable(false);
//
//        //CheckBoxes & TextArea        
//        c1.selectedProperty().addListener(new ChangeListener<Boolean>() {
//            @Override
//            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
//                if (newValue) {
//                    //ticked
//                    flag++;
//                    totalChar += 26;
//                } else {
//                    //unticked
//                    flag--;
//                    totalChar -= 26;
//                }
//                if (flag == 0) {
//                    tNum.setDisable(false);
//                } else {
//                    tNum.setDisable(true);
//                }
//            }
//        });
//
//        c2.selectedProperty().addListener(new ChangeListener<Boolean>() {
//            @Override
//            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
//                if (newValue) {
//                    //ticked
//                    flag++;
//                    totalChar += 26;
//                } else {
//                    //unticked
//                    flag--;
//                    totalChar -= 26;
//                }
//                if (flag == 0) {
//                    tNum.setDisable(false);
//                } else {
//                    tNum.setDisable(true);
//                }
//            }
//        });
//
//        c3.selectedProperty().addListener(new ChangeListener<Boolean>() {
//            @Override
//            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
//                if (newValue) {
//                    //ticked
//                    flag++;
//                    totalChar += 32;
//                } else {
//                    //unticked
//                    flag--;
//                    totalChar -= 32;
//                }
//                if (flag == 0) {
//                    tNum.setDisable(false);
//                } else {
//                    tNum.setDisable(true);
//                }
//            }
//        });

//        tNum.setOnKeyReleased((event) -> {
//
//            if (tNum.getText().charAt(index) < 48 || tNum.getText().charAt(index) > 57) {
//                tNum.setText(tNum.getText().substring(0, index--)+"");
//            }
//            index++;
//        });
}
