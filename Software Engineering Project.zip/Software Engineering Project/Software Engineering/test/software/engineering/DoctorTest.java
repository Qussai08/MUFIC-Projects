/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package software.engineering;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Uchiha Tobi
 */
public class DoctorTest {
    
    public DoctorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getDoctor_ID method, of class Doctor.
     */
    @Test
    public void testGetDoctor_ID() {
        System.out.println("getDoctor_ID");
        Doctor instance = new Doctor();
        int expResult = 15;
        instance.setDoctor_ID(15);
        int result = instance.getDoctor_ID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setDoctor_ID method, of class Doctor.
     */
    @Test
    public void testSetDoctor_ID() {
        System.out.println("setDoctor_ID");
        int Doctor_ID = 17;
        Doctor instance = new Doctor();
        instance.setDoctor_ID(17);
            assertEquals(Doctor_ID, instance.getDoctor_ID());
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }

    /**
     * Test of getUsername method, of class Doctor.
     */
    @Test
    public void testGetUsername() {
        System.out.println("getUsername");
        Doctor instance = new Doctor();
        String expResult = "abc";
        instance.setUsername("abc");
        String result = instance.getUsername();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setUsername method, of class Doctor.
     */
    @Test
    public void testSetUsername() {
        System.out.println("setUsername");
        String Username = "";
        Doctor instance = new Doctor();
        instance.setUsername(Username);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getPassword method, of class Doctor.
     */
    @Test
    public void testGetPassword() {
        System.out.println("getPassword");
        Doctor instance = new Doctor();
        String expResult = "123";
        instance.setPassword("123");
        String Result = instance.getPassword();
        assertEquals(expResult, Result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setPassword method, of class Doctor.
     */
    @Test
    public void testSetPassword() {
        System.out.println("setPassword");
        String Password = "";
        Doctor instance = new Doctor();
        instance.setPassword(Password);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getFirst_Name method, of class Doctor.
     */
    @Test
    public void testGetFirst_Name() {
        System.out.println("getFirst_Name");
        Doctor instance = new Doctor();
        String expResult = "ahmed";
        instance.setFirst_Name("ahmed");
        String Result = instance.getFirst_Name();
        assertEquals(expResult, Result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setFirst_Name method, of class Doctor.
     */
    @Test
    public void testSetFirst_Name() {
        System.out.println("setFirst_Name");
        String First_Name = "";
        Doctor instance = new Doctor();
        instance.setFirst_Name(First_Name);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getLast_Name method, of class Doctor.
     */
    @Test
    public void testGetLast_Name() {
        System.out.println("getLast_Name");
        Doctor instance = new Doctor();
        instance.setLast_Name("hasan");
        String expResult = "hasan";
        String Result = instance.getLast_Name();
        assertEquals(expResult, expResult);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setLast_Name method, of class Doctor.
     */
    @Test
    public void testSetLast_Name() {
        System.out.println("setLast_Name");
        String Last_Name = "";
        Doctor instance = new Doctor();
        instance.setLast_Name(Last_Name);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getTitle method, of class Doctor.
     */
    @Test
    public void testGetTitle() {
        System.out.println("getTitle");
        Doctor instance = new Doctor();
        String expResult = "";
        String Result = instance.getTitle();
        assertEquals(expResult, expResult);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setTitle method, of class Doctor.
     */
    @Test
    public void testSetTitle() {
        System.out.println("setTitle");
        String Title = "";
        Doctor instance = new Doctor();
        instance.setTitle(Title);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getGender method, of class Doctor.
     */
    @Test
    public void testGetGender() {
        System.out.println("getGender");
        Doctor instance = new Doctor();
        String expResult = "";
        String Result = instance.getGender();
        assertEquals(expResult, expResult);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setGender method, of class Doctor.
     */
    @Test
    public void testSetGender() {
        System.out.println("setGender");
        String Gender = "";
        Doctor instance = new Doctor();
        instance.setGender(Gender);
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }

    /**
     * Test of getYears_Of_Experiences method, of class Doctor.
     */
    @Test
    public void testGetYears_Of_Experiences() {
        System.out.println("getYears_Of_Experiences");
        Doctor instance = new Doctor();
        int expResult = 0;
        int Result = instance.getYears_Of_Experiences();
        assertEquals(expResult, expResult);
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }

    /**
     * Test of setYears_Of_Experiences method, of class Doctor.
     */
    @Test
    public void testSetYears_Of_Experiences() {
        System.out.println("setYears_Of_Experiences");
        int Years_Of_Experiences = 0;
        Doctor instance = new Doctor();
        instance.setYears_Of_Experiences(Years_Of_Experiences);
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }

    /**
     * Test of getPhone_Number method, of class Doctor.
     */
    @Test
    public void testGetPhone_Number() {
        System.out.println("getPhone_Number");
        Doctor instance = new Doctor();
        String expResult = "0123";
        instance.setPhone_Number("0123");
        String Result = instance.getPhone_Number();
        assertEquals(expResult, expResult);
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }

    /**
     * Test of setPhone_Number method, of class Doctor.
     */
    @Test
    public void testSetPhone_Number() {
        System.out.println("setPhone_Number");
        String Phone_Number = "";
        Doctor instance = new Doctor();
        instance.setPhone_Number(Phone_Number);
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }

    /**
     * Test of getE_mail method, of class Doctor.
     */
    @Test
    public void testGetE_mail() {
        System.out.println("getE_mail");
        Doctor instance = new Doctor();
        String expResult = "aa@bb.com";
        instance.setE_mail("aa@bb.com");
        String result = instance.getE_mail();
        assertEquals(expResult, expResult);
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }

    /**
     * Test of setE_mail method, of class Doctor.
     */
    @Test
    public void testSetE_mail() {
        System.out.println("setE_mail");
        String E_mail = "";
        Doctor instance = new Doctor();
        instance.setE_mail(E_mail);
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }

    /**
     * Test of getFees method, of class Doctor.
     */
    @Test
    public void testGetFees() {
        System.out.println("getFees");
        Doctor instance = new Doctor();
        int expResult = 0;
        int result = instance.getFees();
        assertEquals(expResult, expResult);
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }

    /**
     * Test of setFees method, of class Doctor.
     */
    @Test
    public void testSetFees() {
        System.out.println("setFees");
        int fees = 0;
        Doctor instance = new Doctor();
        instance.setFees(fees);
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }

    /**
     * Test of getSpecialization method, of class Doctor.
     */
    @Test
    public void testGetSpecialization() {
        System.out.println("getSpecialization");
        Doctor instance = new Doctor();
        String expResult = "";
        String result = instance.getSpecialization();
        assertEquals(expResult, expResult);
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }

    /**
     * Test of setSpecialization method, of class Doctor.
     */
    @Test
    public void testSetSpecialization() {
        System.out.println("setSpecialization");
        String Specialization = "";
        Doctor instance = new Doctor();
        instance.setSpecialization(Specialization);
        // TODO review the generated test code and remove the default call to fail.
        //comment
    }
    
}
