package DB ;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class DeleteClass {
    
    Connection conn;
    Statement stat;
    ResultSet rs;

    
    public void DeleteSystemAdministrator(int id) throws ClassNotFoundException{
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "DELETE FROM System_Admin WHERE Admin_ID = \'" + id +"\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DeleteClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   
    public void DeleteClinic(int id) throws ClassNotFoundException{
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "DELETE FROM Clinic_Table WHERE Clinic_ID = \'" + id +"\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DeleteClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void DeleteDoctor(int id) throws ClassNotFoundException{
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "DELETE FROM Doctor_Table WHERE Doctor_ID = \'" + id +"\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DeleteClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void DeletePatient(int id) throws ClassNotFoundException{
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "DELETE FROM Patient_Table WHERE Patient_ID = \'" + id +"\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DeleteClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void DeleteFeedback(int id) throws ClassNotFoundException{
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "DELETE FROM Feedback_Table WHERE Feedback_ID = \'" + id +"\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DeleteClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void DeleteReservation(int id) throws ClassNotFoundException{
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "DELETE FROM Reservation_Table WHERE Patient_ID = \'" + id +"\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DeleteClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void DeletePatienthistory(int id) throws ClassNotFoundException{
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "DELETE FROM Patient_Histoy  WHERE Patient_ID = \'" + id +"\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DeleteClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
