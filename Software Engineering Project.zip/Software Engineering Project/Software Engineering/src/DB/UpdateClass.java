
package DB;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import software.engineering.Doctor;
import software.engineering.Feedback;
import software.engineering.Patient;
import software.engineering.Reservations;
import software.engineering.SystemAdministrator;
import software.engineering.TheClinic;
import software.engineering.ThePatientsHistory;


public class UpdateClass {
    
     Statement stat;
     
     public void UpdateSystemAdmin(SystemAdministrator sa) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "UPDATE System_Admin SET UserName = '" + sa.getUsername() + "' , Password = '" + sa.getPassword() + "' , First_Name  = '" + sa.getFirst_name() + "' , Last_Name = '" + sa.getLast_name() + "' , Email = '" + sa.getEmail() + "' , Phone_Number = '" + sa.getPhone() + "' WHERE Admin_ID = " + sa.getAdmin_ID() + ";";
            stat.execute(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     public void UpdateClinic(TheClinic cl) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "UPDATE Clinic_Table SET UserName = '" + cl.getUsername() + 
                    "' , Password = '" + cl.getPassword() + "' , Name_of_Clinic = '" +
                    cl.getName_of_Clinic() + "' , City = '" + cl.getCity() + 
                    "' , States = '" + cl.getStates() + "' , Country = '" + 
                    cl.getCountry() + "' , Phone_Number = '" + cl.getPhone_Number() +
                    "' , Email = '" + cl.getE_Mail() +"' , Booking_Info = '" +
                    cl.getBooking_info()+ "' WHERE Clinic_ID = " + cl.getClinic_ID() + ";";
            stat.executeQuery(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     public void UpdateDoctor(Doctor doc) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "UPDATE Doctor_Table SET UserName = '" + doc.getUsername() + "' , Password = '" + doc.getPassword() + "' , First_Name = '" + doc.getFirst_Name() + "' , Last_Name = '" + doc.getLast_Name() + "' , Title = '" + doc.getTitle() + "' , Gender = '" + doc.getGender() + "' , Years_Experiences = " + doc.getYears_Of_Experiences() +" , Phone_Number = '" + doc.getPhone_Number() +"' , Email = '" + doc.getE_mail() + "' , Fees = "+ doc.getFees() +" WHERE Doctor_ID = " + doc.getDoctor_ID() + ";";
            stat.execute(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     public void UpdatePatient(Patient pa) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "UPDATE Patient_Table SET UserName = '" + pa.getUsername() + "' , Password = '" + pa.getPassword() + "' , First_Name = '" + pa.getFirst_Name() + "' , Last_Name = '" + pa.getLast_Name() + "' , Age = " + pa.getAge() + " , Gender = '" + pa.getGender() + "' , Phone_Number = '" + pa.getPhone_Number() +"' , Email = '" + pa.getE_mail() +"' , City = '" + pa.getCity() + "' , States = '"+ pa.getStates() +"' , Country = '" + pa.getCountry() + "' WHERE Patient_ID = " + pa.getPatient_ID() + ";";
            stat.execute(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }   
     
     public void UpdateFeeDBconnectionack(Feedback fb) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "UPDATE FeeDBconnectionack_Table SET Patient_ID = " + fb.getPatient_id() + " , Doctor_ID = "+ fb.getDoctor_id() +" , Clinic_ID = "+ fb.getClinic_id() +"FeeDBconnectionack_Text = '" + fb.getFeedback_text() + "' , Is_showed = " + fb.getIs_showed() + " WHERE FeeDBconnectionack_ID = " + fb.getFeedback_id() + ";";
            stat.execute(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     public void UpdateReservation(Reservations re) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "UPDATE Reservation_Table SET Doctor_ID = " + re.getDoctor_ID() + " , Clinic_ID  = "+ re.getClinic_ID() +" , theDate = '"+ re.getDate() +"' Time = '" + re.getTime() + "' , Is_paied = " + re.getIs_paied() + " WHERE Patient_ID = " + re.getPatient_ID() + ";";
            stat.execute(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     public void UpdatePatienthistory(ThePatientsHistory ph) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "UPDATE Patient_Histoy SET Doctor_ID = " + ph.getDoctor_ID() + " , Clinic_ID  = "+ ph.getClinic_ID() +" , Visit_Date = '"+ ph.getVisit_date() +"' Description = '" + ph.getDescription() + "' , Medical_Prescription = '" + ph.getMedical_Prescription() + "' WHERE Patient_ID = " + ph.getPatient_ID() + ";";
            stat.execute(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
