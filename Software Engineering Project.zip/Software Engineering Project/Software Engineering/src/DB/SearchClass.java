package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import software.engineering.TheClinic;

public class SearchClass {

    private static Statement stat = null;
    static ResultSet rs;

    public static void SearchSystemAdministrator(int id) throws ClassNotFoundException, SQLException {

        stat = DBconnection.getConnection().createStatement();
        String sql = "Select * FROM System_Admin WHERE Admin_ID = \'" + id + "\';";
        stat.execute(sql);
    }

    public static boolean SearchSystemAdministrator(String uname, String Password) throws ClassNotFoundException, SQLException {

        DBconnection.openConnection();
        stat = DBconnection.getConnection().createStatement();
        String sql = "Select * FROM System_Admin WHERE Username = \'" + uname + "\' and Password = \'" + Password + "\';";

        rs = stat.executeQuery(sql);
        boolean found = false;
        while (rs.next()) {
            if (rs.getString("username").equalsIgnoreCase(uname) && rs.getString("password").equalsIgnoreCase(Password)) {
                found = true;
            }
        }
        return found;

    }

    public void SearchClinic(int id) throws ClassNotFoundException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "Select * FROM Clinic_Table WHERE Clinic_ID = \'" + id + "\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void SearchClinic() throws ClassNotFoundException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "Select * FROM Clinic_Table Order By Clinic_ID;";

            rs = stat.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void SearchDoctor(int id) throws ClassNotFoundException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "Select * FROM Doctor_Table WHERE Doctor_ID = \'" + id + "\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void SearchPatient(int id) throws ClassNotFoundException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "Select * FROM Patient_Table WHERE Patient_ID = \'" + id + "\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void SearchFeedback(int id) throws ClassNotFoundException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "Select * FROM Feedback_Table WHERE Feedback_ID = \'" + id + "\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void SearchReservation(int id) throws ClassNotFoundException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "Select * FROM Reservation_Table WHERE Patient_ID = \'" + id + "\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void SearchPatienthistory(int id) throws ClassNotFoundException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "Select * FROM Patient_Histoy  WHERE Patient_ID = \'" + id + "\';";
            stat.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
