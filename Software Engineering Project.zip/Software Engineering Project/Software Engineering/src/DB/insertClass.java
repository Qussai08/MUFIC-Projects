package DB;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import software.engineering.*;

public class insertClass {

    static Statement stat;

    public static void insertSystemAdmin(SystemAdministrator sa) throws SQLException {
        try {

            stat = DBconnection.getConnection().createStatement();
            String sql = "insert into System_Admin values('" + sa.getUsername() + "' , '" + sa.getPassword() + "' , '" + sa.getFirst_name() + "' , '" + sa.getLast_name() + "' , '" + sa.getEmail() + "' , '" + sa.getPhone() + ");";
            stat.execute(sql);
        } catch (Exception ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void insertClinic(TheClinic cl) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "insert into Clinic_Table values (\'" + cl.getClinic_ID()+ "\' ,\'" + cl.getUsername()
                    + "\' , \'" + cl.getPassword() + "\' , \'" + cl.getName_of_Clinic()
                    + "\' , \'" + cl.getCity() + "\' , \'" + cl.getStates() + "\' ,  \'"
                    + cl.getCountry() + "\' , \'" + cl.getPhone_Number() + "\' , \'" + 
                    cl.getE_Mail() + "\' ,  \'" + cl.getBooking_info() + "\');";
            System.out.println(sql);
            stat.execute(sql);
        } catch (Exception ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void insertDoctor(Doctor doc) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "insert into Doctor_Table values ( '" + doc.getUsername() + "' , '" + doc.getPassword() + "' , '" + doc.getFirst_Name() + "' , '" + doc.getLast_Name() + "' ,  '" + doc.getTitle() + "' ,  '" + doc.getGender() + "' ,  " + doc.getYears_Of_Experiences() + " , '" + doc.getPhone_Number() + "' , '" + doc.getE_mail() + "' , " + doc.getFees() + ");";
            stat.execute(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void insertPatient(Patient pa) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "insert into Patient_Table values ( '" + pa.getUsername() + "' , '" + pa.getPassword() + "' , '" + pa.getFirst_Name() + "' , '" + pa.getLast_Name() + "' ,  " + pa.getAge() + " , '" + pa.getGender() + "' , '" + pa.getPhone_Number() + "' , '" + pa.getE_mail() + "' , '" + pa.getCity() + "' , '" + pa.getStates() + "' , '" + pa.getCountry() + ");";
            stat.execute(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void insertFeedback(Feedback fb) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "insert into Feedback_Table values (" + fb.getPatient_id() + " , " + fb.getDoctor_id() + " , " + fb.getClinic_id() + " '" + fb.getFeedback_text() + "' , " + fb.getIs_showed() + ");";
            stat.execute(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void insertReservation(Reservations re) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "insert into Reservation_Table values (" + re.getDoctor_ID() + "," + re.getClinic_ID() + " , '" + re.getDate() + "' '" + re.getTime() + "' , " + re.getIs_paied() + ");";
            stat.execute(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void insertPatienthistory(ThePatientsHistory ph) throws SQLException {
        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "insert into Patient_Histoy values (" + ph.getDoctor_ID() + "," + ph.getClinic_ID() + ",'" + ph.getVisit_date() + "','" + ph.getDescription() + "','" + ph.getMedical_Prescription() + "');";
            stat.execute(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
