/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FXML;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;

/**
 * FXML Controller class
 *
 * @author Mahmoud Qussai
 */
public class MedicalHistoryPanelController implements Initializable {
    @FXML
    private TextArea fPres;
    @FXML
    private Button bExit;
    @FXML
    private Font x2;
    @FXML
    private Button bPrint;
    @FXML
    private Button bAdd;
    @FXML
    private Button bBack;
    @FXML
    private TextArea fDesc;
    @FXML
    private TableColumn<?, ?> cDate;
    @FXML
    private TableColumn<?, ?> cDecs;
    @FXML
    private TableColumn<?, ?> cPres;
    @FXML
    private Font x1;
    @FXML
    private TextField fDate;
    @FXML
    private Pane pane;
    
    Pane a;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void toExit(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void toPrint(ActionEvent event) {
    }

    @FXML
    private void toAdd(ActionEvent event) {
    }

    @FXML
    private void toBack(ActionEvent event) throws IOException {
        a = FXMLLoader.load(this.getClass().getResource("doctorPanel.fxml"));
        pane.getChildren().setAll(a);
    }
    
}
