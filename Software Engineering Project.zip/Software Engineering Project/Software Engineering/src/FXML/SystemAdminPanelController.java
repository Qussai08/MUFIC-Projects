/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FXML;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import DB.*;
import static FXML.SystemAdminLoginController.rs;
import static FXML.SystemAdminLoginController.stat;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.StageStyle;
import javax.swing.JOptionPane;
import software.engineering.*;

/**
 * FXML Controller class
 *
 * @author Mahmoud Qussai
 */
public class SystemAdminPanelController implements Initializable {

    @FXML
    private Font x1;
    @FXML
    private TextField fID;
    @FXML
    private Button bBack;
    @FXML
    private Font x2;
    @FXML
    private TextField fName;
    @FXML
    private TextField fUsername;
    @FXML
    private TextField fPassword;
    @FXML
    private TextField fCity;
    @FXML
    private TextField fState;
    @FXML
    private TextField fCountry;
    @FXML
    private TextField fPhone;
    @FXML
    private TextField fEmail;
    @FXML
    private TextField fInfo;
    @FXML
    private Button bDelete;
    @FXML
    private Button bEdit;
    @FXML
    private Button bAdd;
    @FXML
    private TextField fSearch;
    @FXML
    private Button bDone;
    @FXML
    private Button bSearch;
    @FXML
    private TableColumn<TheClinic, Integer> cID;
    @FXML
    private TableColumn<TheClinic, String> cUsername;
    @FXML
    private TableColumn<TheClinic, String> cPassword;
    @FXML
    private TableColumn<TheClinic, String> cName;
    @FXML
    private TableColumn<TheClinic, String> cCity;
    @FXML
    private TableColumn<TheClinic, String> cState;
    @FXML
    private TableColumn<TheClinic, String> cCountry;
    @FXML
    private TableColumn<TheClinic, String> cPhone;
    @FXML
    private TableColumn<TheClinic, String> cEmail;
    @FXML
    private TableColumn<TheClinic, String> cInfo;
    @FXML
    private Button bExit;
    @FXML
    private TableView<TheClinic> clinicTable;
    ObservableList<TheClinic> clinicData;

    int count1 = -1;
    int newId2;
    TheClinic newValues2;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        clinicData = FXCollections.observableArrayList();
        clinicTable.setEditable(true);

        cID.setCellValueFactory(new PropertyValueFactory<>("Clinic_ID"));
        cName.setCellValueFactory(new PropertyValueFactory<>("Name_of_Clinic"));
        cName.setCellFactory(TextFieldTableCell.forTableColumn());
        cName.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<TheClinic, String>>() {

            @Override
            public void handle(TableColumn.CellEditEvent<TheClinic, String> event) {
                ((TheClinic) event.getTableView().getItems().get(event.getTablePosition().getRow())).setName_of_Clinic(event.getNewValue());
            }
        });

        cUsername.setCellValueFactory(new PropertyValueFactory<>("Username"));
        cUsername.setCellFactory(TextFieldTableCell.forTableColumn());
        cUsername.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<TheClinic, String>>() {

            @Override
            public void handle(TableColumn.CellEditEvent<TheClinic, String> event) {
                ((TheClinic) event.getTableView().getItems().get(event.getTablePosition().getRow())).setUsername(event.getNewValue());
            }
        });

        cPassword.setCellValueFactory(new PropertyValueFactory<>("Password"));
        cPassword.setCellFactory(TextFieldTableCell.forTableColumn());
        cPassword.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<TheClinic, String>>() {

            @Override
            public void handle(TableColumn.CellEditEvent<TheClinic, String> event) {
                ((TheClinic) event.getTableView().getItems().get(event.getTablePosition().getRow())).setPassword(event.getNewValue());
            }
        });

        cCity.setCellValueFactory(new PropertyValueFactory<>("City"));
        cCity.setCellFactory(TextFieldTableCell.forTableColumn());
        cCity.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<TheClinic, String>>() {

            @Override
            public void handle(TableColumn.CellEditEvent<TheClinic, String> event) {
                ((TheClinic) event.getTableView().getItems().get(event.getTablePosition().getRow())).setCity(event.getNewValue());
            }
        });

        cState.setCellValueFactory(new PropertyValueFactory<>("States"));
        cState.setCellFactory(TextFieldTableCell.forTableColumn());
        cState.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<TheClinic, String>>() {

            @Override
            public void handle(TableColumn.CellEditEvent<TheClinic, String> event) {
                ((TheClinic) event.getTableView().getItems().get(event.getTablePosition().getRow())).setStates(event.getNewValue());
            }
        });

        cCountry.setCellValueFactory(new PropertyValueFactory<>("Country"));
        cCountry.setCellFactory(TextFieldTableCell.forTableColumn());
        cCountry.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<TheClinic, String>>() {

            @Override
            public void handle(TableColumn.CellEditEvent<TheClinic, String> event) {
                ((TheClinic) event.getTableView().getItems().get(event.getTablePosition().getRow())).setCountry(event.getNewValue());
            }
        });

        cPhone.setCellValueFactory(new PropertyValueFactory<>("Phone_Number"));
        cPhone.setCellFactory(TextFieldTableCell.forTableColumn());
        cPhone.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<TheClinic, String>>() {

            @Override
            public void handle(TableColumn.CellEditEvent<TheClinic, String> event) {
                ((TheClinic) event.getTableView().getItems().get(event.getTablePosition().getRow())).setPhone_Number(event.getNewValue());
            }
        });

        cEmail.setCellValueFactory(new PropertyValueFactory<>("E_Mail"));
        cEmail.setCellFactory(TextFieldTableCell.forTableColumn());
        cEmail.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<TheClinic, String>>() {

            @Override
            public void handle(TableColumn.CellEditEvent<TheClinic, String> event) {
                ((TheClinic) event.getTableView().getItems().get(event.getTablePosition().getRow())).setE_Mail(event.getNewValue());
            }
        });

        cInfo.setCellValueFactory(new PropertyValueFactory<>("Booking_info"));
        cInfo.setCellFactory(TextFieldTableCell.forTableColumn());
        cInfo.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<TheClinic, String>>() {

            @Override
            public void handle(TableColumn.CellEditEvent<TheClinic, String> event) {
                ((TheClinic) event.getTableView().getItems().get(event.getTablePosition().getRow())).setBooking_info(event.getNewValue());
            }
        });
        clinicTable.setItems(clinicData);

        try {
            stat = DBconnection.getConnection().createStatement();
            String sql = "Select * FROM Clinic_Table Order By Clinic_ID;";

            rs = stat.executeQuery(sql);
            while (rs.next()) {
                clinicData.add(new TheClinic(rs.getInt("clinic_id"), rs.getString("Username"), rs.getString("Password"), rs.getString("name_of_clinic"), rs.getString("City"), rs.getString("States"), rs.getString("Country"), rs.getString("Phone_Number"), rs.getString("Email"), rs.getString("Booking_Info")));
                clinicTable.setItems(clinicData);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SystemAdminPanelController.class.getName()).log(Level.SEVERE, null, ex);
        }

        TableView.TableViewSelectionModel<TheClinic> tableSelectionModel1 = clinicTable.getSelectionModel();
        ReadOnlyObjectProperty rowClicked1 = tableSelectionModel1.selectedItemProperty();
        rowClicked1.addListener(new ChangeListener<TheClinic>() {
            @Override

            public void changed(ObservableValue<? extends TheClinic> observable, TheClinic oldValue, TheClinic newValue) {
                try {
                    newId2 = (observable.getValue().getClinic_ID());
                    for (int i = 0; i < clinicData.size(); i++) {
                        if (clinicData.get(i).getClinic_ID() == newValue.getClinic_ID()) {
                            count1 = i;
                            break;
                        }
                    }

                    newValues2 = newValue;

                } catch (NullPointerException e) {
                }
            }
        });
        if (count1 > -1) {
            clinicData.set(count1, newValues2);
        }

    }

    @FXML
    private void toBack(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("systemAdminLogin.fxml"));

        Scene scene = new Scene(root);
        
        stage.initStyle(StageStyle.UNDECORATED);
        stage.setScene(scene);
        stage.show();
        ((Node) event.getSource()).getScene().getWindow().hide();
    }

    @FXML
    private void toDelete(ActionEvent event) throws SQLException {
        int confirm = JOptionPane.showConfirmDialog(null, "Do you Want to Delete " + newValues2.getName_of_Clinic());
        if (confirm == JOptionPane.YES_OPTION) {
            String SQL = "delete from `Clinic_Table` where `Clinic_id` = " + newId2;
            stat.executeUpdate(SQL);
            try {
                ObservableList<TheClinic> clinicData = FXCollections.observableArrayList();
                stat = DBconnection.getConnection().createStatement();
                String sql = "Select * FROM Clinic_Table Order By Clinic_ID;";

                rs = stat.executeQuery(sql);
                while (rs.next()) {
                    clinicData.add(new TheClinic(rs.getInt("clinic_id"), rs.getString("Username"),
                            rs.getString("Password"), rs.getString("name_of_clinic"),
                            rs.getString("City"), rs.getString("States"), rs.getString("Country"),
                            rs.getString("Phone_Number"), rs.getString("Email"), rs.getString("Booking_Info")));
                    clinicTable.setItems(clinicData);
                }
            } catch (SQLException ex) {
                Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(SystemAdminPanelController.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Entry has been Deleted");
        }
    }

    @FXML
    private void toEdit(ActionEvent event) {
        for (int i = 0; i < clinicData.size(); i++) {

            try {
                String sql = "UPDATE Clinic_Table SET UserName = '" + clinicData.get(i).getUsername()
                        + "' , Password = '" + clinicData.get(i).getPassword() + "' , Name_of_Clinic = '"
                        + clinicData.get(i).getName_of_Clinic() + "' , City = '" + clinicData.get(i).getCity()
                        + "' , States = '" + clinicData.get(i).getStates() + "' , Country = '"
                        + clinicData.get(i).getCountry() + "' , Phone_Number = '" + clinicData.get(i).getPhone_Number()
                        + "' , Email = '" + clinicData.get(i).getE_Mail() + "' , Booking_Info = '"
                        + clinicData.get(i).getBooking_info() + "' WHERE Clinic_ID = " + clinicData.get(i).getClinic_ID() + ";";
                System.out.println(sql);
                stat.executeUpdate(sql);
            } catch (SQLException ex) {
                Logger.getLogger(SystemAdminPanelController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        JOptionPane.showMessageDialog(null, "Table has been Updated");
    }

    @FXML
    private void toAdd(ActionEvent event) {
        try {
            insertClass.insertClinic(new TheClinic(Integer.parseInt(fID.getText()),
                    fUsername.getText(), fPassword.getText(), fName.getText(),
                    fCity.getText(), fState.getText(), fCountry.getText(), fPhone.getText(),
                    fEmail.getText(), fInfo.getText()));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
        try {
            ObservableList<TheClinic> clinicData = FXCollections.observableArrayList();
            stat = DBconnection.getConnection().createStatement();
            String sql = "Select * FROM Clinic_Table Order By Clinic_ID;";

            rs = stat.executeQuery(sql);
            while (rs.next()) {
                clinicData.add(new TheClinic(rs.getInt("clinic_id"), rs.getString("Username"),
                        rs.getString("Password"), rs.getString("name_of_clinic"),
                        rs.getString("City"), rs.getString("States"), rs.getString("Country"),
                        rs.getString("Phone_Number"), rs.getString("Email"), rs.getString("Booking_Info")));
                clinicTable.setItems(clinicData);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SystemAdminPanelController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void toDone(ActionEvent event) {
        try {
            ObservableList<TheClinic> clinicData = FXCollections.observableArrayList();
            stat = DBconnection.getConnection().createStatement();
            String sql = "Select * FROM Clinic_Table Order By Clinic_ID;";

            rs = stat.executeQuery(sql);
            while (rs.next()) {
                clinicData.add(new TheClinic(rs.getInt("clinic_id"), rs.getString("Username"),
                        rs.getString("Password"), rs.getString("name_of_clinic"),
                        rs.getString("City"), rs.getString("States"), rs.getString("Country"),
                        rs.getString("Phone_Number"), rs.getString("Email"), rs.getString("Booking_Info")));
                clinicTable.setItems(clinicData);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SystemAdminPanelController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void toSearch(ActionEvent event) {
        try {
            ObservableList<TheClinic> clinicData = FXCollections.observableArrayList();
            stat = DBconnection.getConnection().createStatement();
            String sql = "Select * FROM Clinic_Table where name_of_clinic = '" + fSearch.getText() + "';";

            rs = stat.executeQuery(sql);
            while (rs.next()) {
                clinicData.add(new TheClinic(rs.getInt("clinic_id"), rs.getString("Username"),
                        rs.getString("Password"), rs.getString("name_of_clinic"),
                        rs.getString("City"), rs.getString("States"), rs.getString("Country"),
                        rs.getString("Phone_Number"), rs.getString("Email"), rs.getString("Booking_Info")));
                clinicTable.setItems(clinicData);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SearchClass.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SystemAdminPanelController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void toExit(ActionEvent event) {
        System.exit(0);
    }

}
