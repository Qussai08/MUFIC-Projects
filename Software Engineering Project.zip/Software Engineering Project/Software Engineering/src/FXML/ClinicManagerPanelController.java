/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FXML;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author Mahmoud Qussai
 */
public class ClinicManagerPanelController implements Initializable {

    @FXML
    private Pane pane;
    @FXML
    private Font x1;
    @FXML
    private TextField fUsername;
    @FXML
    private Button bBack;
    @FXML
    private Font x2;
    @FXML
    private TextField fPassword;
    @FXML
    private TextField fFirstName;
    @FXML
    private TextField fFLastName;
    @FXML
    private TextField fTitle;
    @FXML
    private TextField fGender;
    @FXML
    private TextField fSpec;
    @FXML
    private TextField fYears;
    @FXML
    private TextField fPhone;
    @FXML
    private TextField fEmail;
    @FXML
    private Button bDelete;
    @FXML
    private Button bEdit;
    @FXML
    private Button bAdd;
    @FXML
    private TextField fSearch;
    @FXML
    private Button bDone;
    @FXML
    private Button bSearch;
    @FXML
    private TableColumn<?, ?> cUsername;
    @FXML
    private TableColumn<?, ?> cPassword;
    @FXML
    private TableColumn<?, ?> cFirstName;
    @FXML
    private TableColumn<?, ?> cLastName;
    @FXML
    private TableColumn<?, ?> cTitle;
    @FXML
    private TableColumn<?, ?> cGender;
    @FXML
    private TableColumn<?, ?> cSpec;
    @FXML
    private TableColumn<?, ?> cYears;
    @FXML
    private TableColumn<?, ?> cPhone;
    @FXML
    private TableColumn<?, ?> cEmail;
    @FXML
    private TableColumn<?, ?> cFees;
    @FXML
    private Button bExit;
    @FXML
    private TextField fFees;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void toBack(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("clinicManagerLogin.fxml"));

        Scene scene = new Scene(root);

        stage.initStyle(StageStyle.UNDECORATED);
        stage.setScene(scene);
        stage.show();
        ((Node) event.getSource()).getScene().getWindow().hide();
    }

    @FXML
    private void toDelete(ActionEvent event) {
    }

    @FXML
    private void toEdit(ActionEvent event) {
    }

    @FXML
    private void toAdd(ActionEvent event) {
    }

    @FXML
    private void toDone(ActionEvent event) {
    }

    @FXML
    private void toSearch(ActionEvent event) {
    }

    @FXML
    private void toExit(ActionEvent event) {
        System.exit(0);
    }

}
