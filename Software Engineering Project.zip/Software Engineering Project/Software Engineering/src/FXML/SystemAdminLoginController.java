/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FXML;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javax.swing.JOptionPane;
import DB.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import sun.security.util.Password;

/**
 * FXML Controller class
 *
 * @author Mahmoud Qussai
 */
public class SystemAdminLoginController extends SoftwareEngineering implements Initializable {

    @FXML
    private Button loginBtn;
    @FXML
    private TextField unameText;
    @FXML
    private PasswordField passwordText;
    @FXML
    private Button backBtn;
    @FXML
    private Pane pane;

    Pane a;

    /**
     * Initializes the controller class.
     */
    static Statement stat;
    static ResultSet rs;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void login(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {

        if (SearchClass.SearchSystemAdministrator(unameText.getText(), passwordText.getText()) == true) {
            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("systemAdminPanel.fxml"));

            Scene scene = new Scene(root);
            
            stage.initStyle(StageStyle.UNDECORATED);
            stage.setScene(scene);
            stage.show();
            ((Node) event.getSource()).getScene().getWindow().hide();
        } else {
            JOptionPane.showMessageDialog(null, "Invalid Username or Password");
        }
    }

    @FXML
    private void back(ActionEvent event) throws IOException {
        a = FXMLLoader.load(this.getClass().getResource("main.fxml"));
        pane.getChildren().setAll(a);
    }

}
