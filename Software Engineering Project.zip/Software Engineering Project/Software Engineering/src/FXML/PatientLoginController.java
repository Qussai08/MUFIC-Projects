/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FXML;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * FXML Controller class
 *
 * @author Mahmoud Qussai
 */
public class PatientLoginController implements Initializable {

    @FXML
    private Color x2;
    @FXML
    private Font x1;
    @FXML
    private Font x3;
    @FXML
    private Button backBtn;
    @FXML
    private TextField unameText;
    @FXML
    private PasswordField passwordTet;
    @FXML
    private Button loginBtn;
    @FXML
    private Button registerBtn;

    Pane a;
    @FXML
    private Pane pane;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void back(ActionEvent event) throws IOException {
        a = FXMLLoader.load(this.getClass().getResource("main.fxml"));
        pane.getChildren().setAll(a);
    }

    @FXML
    private void login(ActionEvent event) throws IOException {
        a = FXMLLoader.load(this.getClass().getResource("patientPanel.fxml"));
        pane.getChildren().setAll(a);
    }

    @FXML
    private void register(ActionEvent event) throws IOException {
        a = FXMLLoader.load(this.getClass().getResource("patientRegister.fxml"));
        pane.getChildren().setAll(a);
    }

}
