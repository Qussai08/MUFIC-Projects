/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FXML;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;

/**
 * FXML Controller class
 *
 * @author Mahmoud Qussai
 */
public class DoctorLoginController implements Initializable {
    @FXML
    private Pane pane;
    @FXML
    private TextField unameText;
    @FXML
    private Button backBtn;
    @FXML
    private Button loginBtn;
    
    Pane a ;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void back(ActionEvent event) throws IOException {
        a = FXMLLoader.load(this.getClass().getResource("main.fxml"));
        pane.getChildren().setAll(a);
    }

    @FXML
    private void login(ActionEvent event) throws IOException {
        a = FXMLLoader.load(this.getClass().getResource("doctorPanel.fxml"));
        pane.getChildren().setAll(a);
    }
    
}
