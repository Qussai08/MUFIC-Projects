/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FXML;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Mahmoud Qussai
 */
public class DoctorPanelController implements Initializable {

    @FXML
    private Button bBack;
    @FXML
    private Font x2;
    @FXML
    private TableColumn<?, ?> cID;
    @FXML
    private TableColumn<?, ?> cName;
    @FXML
    private TableColumn<?, ?> cFees;
    @FXML
    private Button bExit;
    @FXML
    private Button bView;
    @FXML
    private Pane pane;

    Pane a;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void toBack(ActionEvent event) throws IOException {
        a = FXMLLoader.load(this.getClass().getResource("doctorLogin.fxml"));
        pane.getChildren().setAll(a);
    }

    @FXML
    private void toExit(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void toView(ActionEvent event) throws IOException {
        a = FXMLLoader.load(getClass().getResource("medicalHistoryPanel.fxml"));
        pane.getChildren().setAll(a);

    }

}
