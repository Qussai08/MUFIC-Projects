/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FXML;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Mahmoud Qussai
 */
public class PatientRegisterController implements Initializable {

    @FXML
    private Font x1;
    @FXML
    private TextField fID;
    @FXML
    private Button bBack;
    @FXML
    private Font x2;
    @FXML
    private TextField fUsername;
    @FXML
    private TextField fPassword;
    @FXML
    private TextField fName;
    @FXML
    private TextField fState;
    @FXML
    private TextField fCountry;
    @FXML
    private TextField fPhone;
    @FXML
    private TextField fEmail;
    @FXML
    private TextField fInfo;
    @FXML
    private Button bSign;
    @FXML
    private Button bExit;
    @FXML
    private ComboBox<?> fGender;
    @FXML
    private Pane pane;

    Pane a;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void toBack(ActionEvent event) throws IOException {
        a = FXMLLoader.load(this.getClass().getResource("patientLogin.fxml"));
        pane.getChildren().setAll(a);
    }

    @FXML
    private void toSign(ActionEvent event) {
        JOptionPane.showMessageDialog(null, "Congratulations You're Registered Now");
    }

    @FXML
    private void toExit(ActionEvent event) {
        System.exit(0);
    }

}
