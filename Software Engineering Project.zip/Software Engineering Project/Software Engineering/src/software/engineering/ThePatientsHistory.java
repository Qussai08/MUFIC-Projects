package software.engineering;

public class ThePatientsHistory {
    private int Patient_ID;
    private int Doctor_ID;
    private int Clinic_ID;
    private String Visit_date;
    private String Description;
    private String Medical_Prescription;


    public int getPatient_ID() {
        return Patient_ID;
    }

    public void setPatient_ID(int Patient_ID) {
        this.Patient_ID = Patient_ID;
    }

    public int getDoctor_ID() {
        return Doctor_ID;
    }

    public void setDoctor_ID(int Doctor_ID) {
        this.Doctor_ID = Doctor_ID;
    }

    public int getClinic_ID() {
        return Clinic_ID;
    }

    public void setClinic_ID(int Clinic_ID) {
        this.Clinic_ID = Clinic_ID;
    }

    public String getVisit_date() {
        return Visit_date;
    }

    public void setVisit_date(String Visit_date) {
        this.Visit_date = Visit_date;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getMedical_Prescription() {
        return Medical_Prescription;
    }

    public void setMedical_Prescription(String Medical_Prescription) {
        this.Medical_Prescription = Medical_Prescription;
    }
}
