
package software.engineering;

public class Doctor {
   
    private int Doctor_ID;
    private String Username;
    private String Password;
    private String First_Name;
    private String Last_Name;
    private String Title;
    private String Gender;
    private int Years_Of_Experiences;
    private String Phone_Number;
    private String E_mail;
    private int fees;
    private String Specialization;

    
    public int getDoctor_ID() {
        return Doctor_ID;
    }

    public void setDoctor_ID(int Doctor_ID) {
        this.Doctor_ID = Doctor_ID;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public void setFirst_Name(String First_Name) {
        this.First_Name = First_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public void setLast_Name(String Last_Name) {
        this.Last_Name = Last_Name;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public int getYears_Of_Experiences() {
        return Years_Of_Experiences;
    }

    public void setYears_Of_Experiences(int Years_Of_Experiences) {
        this.Years_Of_Experiences = Years_Of_Experiences;
    }

    public String getPhone_Number() {
        return Phone_Number;
    }

    public void setPhone_Number(String Phone_Number) {
        this.Phone_Number = Phone_Number;
    }

    public String getE_mail() {
        return E_mail;
    }

    public void setE_mail(String E_mail) {
        this.E_mail = E_mail;
    }

    public int getFees() {
        return fees;
    }

    public void setFees(int fees) {
        this.fees = fees;
    }

    
    public String getSpecialization() {
        return Specialization;
    }

    
    public void setSpecialization(String Specialization) {
        this.Specialization = Specialization;
    }
    
    
}
