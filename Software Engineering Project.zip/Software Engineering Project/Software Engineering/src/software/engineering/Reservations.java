
package software.engineering;


public class Reservations {
    
 private int Patient_ID;
private int Doctor_ID;
private int Clinic_ID;
private String date;
private String time;
private int Is_paied;

    public int getPatient_ID() {
        return Patient_ID;
    }

    public void setPatient_ID(int Patient_ID) {
        this.Patient_ID = Patient_ID;
    }

    public int getDoctor_ID() {
        return Doctor_ID;
    }

    public void setDoctor_ID(int Doctor_ID) {
        this.Doctor_ID = Doctor_ID;
    }

    public int getClinic_ID() {
        return Clinic_ID;
    }

    public void setClinic_ID(int Clinic_ID) {
        this.Clinic_ID = Clinic_ID;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getIs_paied() {
        return Is_paied;
    }

    public void setIs_paied(int Is_paied) {
        this.Is_paied = Is_paied;
    }

    
}
