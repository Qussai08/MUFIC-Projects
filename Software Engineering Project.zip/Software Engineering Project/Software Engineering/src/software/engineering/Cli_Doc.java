
package software.engineering;

public class Cli_Doc {
   
    private int Clinic_ID;
    private int Doctor_ID;


    public int getClinic_ID() {
        return Clinic_ID;
    }

    public void setClinic_ID(int Clinic_ID) {
        this.Clinic_ID = Clinic_ID;
    }

    public int getDoctor_ID() {
        return Doctor_ID;
    }

    public void setDoctor_ID(int Doctor_ID) {
        this.Doctor_ID = Doctor_ID;
    }
    
    
}
