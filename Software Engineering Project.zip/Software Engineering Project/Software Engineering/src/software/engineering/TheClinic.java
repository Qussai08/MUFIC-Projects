package software.engineering;

public class TheClinic {
    private int Clinic_ID;
    private String username;
    private String password;
    private String Name_of_Clinic;
    private String City;
    private String States;
    private String Country;
    private String Phone_Number;
    private String E_Mail;
    private String Booking_info;

    public TheClinic(int Clinic_ID, String username, String password, String Name_of_Clinic, String City, String States, String Country, String Phone_Number, String E_Mail, String Booking_info) {
        this.Clinic_ID = Clinic_ID;
        this.username = username;
        this.password = password;
        this.Name_of_Clinic = Name_of_Clinic;
        this.City = City;
        this.States = States;
        this.Country = Country;
        this.Phone_Number = Phone_Number;
        this.E_Mail = E_Mail;
        this.Booking_info = Booking_info;
    }


    
    public int getClinic_ID() {
        return Clinic_ID;
    }

    public void setClinic_ID(int Clinic_ID) {
        this.Clinic_ID = Clinic_ID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName_of_Clinic() {
        return Name_of_Clinic;
    }

    public void setName_of_Clinic(String Name_of_Clinic) {
        this.Name_of_Clinic = Name_of_Clinic;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getStates() {
        return States;
    }

    public void setStates(String States) {
        this.States = States;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public String getPhone_Number() {
        return Phone_Number;
    }

    public void setPhone_Number(String Phone_Number) {
        this.Phone_Number = Phone_Number;
    }

    public String getE_Mail() {
        return E_Mail;
    }

    public void setE_Mail(String E_Mail) {
        this.E_Mail = E_Mail;
    }

    public String getBooking_info() {
        return Booking_info;
    }

    public void setBooking_info(String Booking_info) {
        this.Booking_info = Booking_info;
    }
    
}
