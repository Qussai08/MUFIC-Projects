
package software.engineering;


public class Feedback {

    private int feedback_id;
    private int Patient_id;
    private int doctor_id;
    private int clinic_id;
    private String feedback_text;
    private int is_showed;

    public int getFeedback_id() {
        return feedback_id;
    }

    public void setFeedback_id(int feedback_id) {
        this.feedback_id = feedback_id;
    }

    public int getPatient_id() {
        return Patient_id;
    }

    public void setPatient_id(int Patient_id) {
        this.Patient_id = Patient_id;
    }

    public int getDoctor_id() {
        return doctor_id;
    }

    public void setDoctor_id(int doctor_id) {
        this.doctor_id = doctor_id;
    }

    public int getClinic_id() {
        return clinic_id;
    }

    public void setClinic_id(int clinic_id) {
        this.clinic_id = clinic_id;
    }

    public String getFeedback_text() {
        return feedback_text;
    }

    public void setFeedback_text(String feedback_text) {
        this.feedback_text = feedback_text;
    }

    public int getIs_showed() {
        return is_showed;
    }

    public void setIs_showed(int is_showed) {
        this.is_showed = is_showed;
    }

}
