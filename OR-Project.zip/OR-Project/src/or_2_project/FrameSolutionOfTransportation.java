package or_2_project;

import java.awt.GridLayout;
import javax.swing.*;

public class FrameSolutionOfTransportation extends JFrame {

    static int numberOfResources = GuiTransportation.numberOfResources;
    static int numberOfDeamnds = GuiTransportation.numberOfdemands;
    static JTextField[][] text_Solution = new JTextField[numberOfResources][numberOfDeamnds];

    public FrameSolutionOfTransportation() {

        setLayout(new GridLayout((numberOfResources), (numberOfDeamnds)));

        for (int i = 0; i < text_Solution.length; i++) {
            for (int j = 0; j < text_Solution[i].length; j++) {

                text_Solution[i][j] = new JTextField();
                add(text_Solution[i][j]);
                text_Solution[i][j].setEditable(false);
            }
        }

        setTitle(" FINAL RESULT ");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);
        setVisible(true);

    }
//    public static void main(String[] args) {
//        FrameSolutionOfTransportation f = new FrameSolutionOfTransportation();
//    }
}
