package or_2_project;

import java.awt.Font;
import javax.swing.JOptionPane;

public class Vogel {

    double[][] Demands_Recources_Solution;
    double[][] Costs;
    double[] Resources;
    double[] Demands;
    double[] PanlityDemands;
    double[] PanlityResources;
    double SumResources = 0, SumDemands = 0;
    int NumberOfDemands;
    int numberOfResources;
    double min1 = 99999999999.0, min2 = 9999999999.0;
    int Counter1 = 0;
    int IndexmaxPanilityResources = 0;
    double maxPanlityResources = 0.0;
    int Counter2 = 0;
    int Rowdeleted[];
    int Columndeleted[];
    double min3 = 99999999999.0, min4 = 9999999999.0;
    int IndexmaxPanilityDemands = 0;
    double maxPanlityDemands = 0.0;
    double MinCostChoosen_1 = 9999999999999999999.0;
    double MinCostChoosen_2 = 9999999999999999999.0;
    int IndexMinCostChoosen_1 = 0;
    int IndexMinCostChoosen_2 = 0;
    int numberRowsDeleted = 0;
    int numberColumnsdeleted = 0;
    int Counter_Zero_Demands = 0;
    int Counter_Zero_Resources = 0;
    boolean StopProcess1 = false;
    boolean Stopprocess2 = false;
    double[][] Costs2;
    boolean Final = false;
    FrameSolutionOfTransportation frame = new FrameSolutionOfTransportation();

    public Vogel() {

        NumberOfDemands = GuiTransportation.numberOfdemands;
        numberOfResources = GuiTransportation.numberOfResources;
        Demands_Recources_Solution = new double[numberOfResources][NumberOfDemands];
        Costs = new double[numberOfResources][NumberOfDemands];
        Demands = new double[NumberOfDemands];
        Resources = new double[numberOfResources];
        Costs = GuiTransportation.Costs;
        Demands = GuiTransportation.Demands;
        Resources = GuiTransportation.Resources;
        PanlityDemands = new double[NumberOfDemands];
        PanlityResources = new double[numberOfResources];
        Rowdeleted = new int[numberOfResources];
        Columndeleted = new int[NumberOfDemands];

        for (int i = 0; i < numberOfResources; i++) {

            Rowdeleted[i] = -1;
        }
        for (int i = 0; i < NumberOfDemands; i++) {

            Columndeleted[i] = -1;
        }

    }

    public boolean Check() {

        boolean Check = false;

        for (int i = 0; i < Demands.length; i++) {
            if (Demands[i] == 0) {
                Counter_Zero_Demands++;
            }
        }
        for (int i = 0; i < Resources.length; i++) {
            if (Resources[i] == 0) {
                Counter_Zero_Resources++;
            }
        }

        if (Counter_Zero_Demands == NumberOfDemands && Counter_Zero_Resources == numberOfResources) {

            Check = true;
            System.out.println("Not Allowed ");
        }
        return Check;
    }

    public void CalculatePanlity() {

        if (SumResources == SumDemands) {

            for (int j = 0; j < numberOfResources; j++) {
                for (int k = 0; k < NumberOfDemands; k++) {

                    if (Costs[j][k] < min1 && Rowdeleted[j] == -1 && Columndeleted[k] == -1) {

                        min1 = Costs[j][k];
                    }
                }
                for (int z = 0; z < NumberOfDemands; z++) {

                    if (Costs[j][z] == min1 && Rowdeleted[j] == -1 && Columndeleted[z] == -1) {

                        Counter1++;
                    }

                }
                for (int i = 0; i < NumberOfDemands; i++) {

                    if (Counter1 < 2) {
                        if (Costs[j][i] < min2 && Costs[j][i] != min1 && Rowdeleted[j] == -1 && Columndeleted[i] == -1) {

                            min2 = Costs[j][i];
                        }
                    } else if (Costs[j][i] < min2 && Counter1 >= 2 && Rowdeleted[j] == -1 && Columndeleted[i] == -1) {

                        min2 = Costs[j][i];
                    }
                }

                PanlityResources[j] = Math.abs(min1 - min2);
                min1 = 99999999999.0;
                min2 = 99999999999.0;
                Counter1 = 0;
            }

            for (int i = 0; i < PanlityResources.length; i++) {

                System.out.println("panility resources " + PanlityResources[i]);
            }

            for (int i = 0; i < PanlityResources.length; i++) {

                if (PanlityResources[i] >= maxPanlityResources && Rowdeleted[i] == -1) {
                    maxPanlityResources = PanlityResources[i];
                    IndexmaxPanilityResources = i;
                }
            }

            System.out.println("max Panlity Resources = : " + maxPanlityResources);
            System.out.println(" Index of it is : " + IndexmaxPanilityResources);


////////////////////////////////////////////////////////////////////////////////
            Costs2 = new double[NumberOfDemands][numberOfResources];

            for (int i = 0; i < numberOfResources; i++) {
                for (int j = 0; j < NumberOfDemands; j++) {

                    Costs2[j][i] = Costs[i][j];
                }
            }

////////////////////////////////////////////////////////////////////////////////

            for (int j = 0; j < Costs2.length; j++) {
                for (int k = 0; k < Costs2[j].length; k++) {

                    if (Costs2[j][k] < min3 && Columndeleted[j] == -1 && Rowdeleted[k] == -1) {

                        min3 = Costs2[j][k];
                    }
                }
                for (int z = 0; z < Costs2[j].length; z++) {

                    if (Costs2[j][z] == min3 && Columndeleted[j] == -1 && Columndeleted[z] == -1) {

                        Counter2++;
                    }
                }
                for (int i = 0; i < Costs2[j].length; i++) {

                    if (Counter2 < 2) {
                        if (Costs2[j][i] < min4 && Costs2[j][i] != min3 && Columndeleted[j] == -1 && Columndeleted[i] == -1) {

                            min4 = Costs2[j][i];

                        }
                    } else if (Costs2[j][i] < min4 && Counter2 >= 2 && Columndeleted[j] == -1 && Columndeleted[i] == -1) {

                        min4 = Costs2[j][i];
                    }

                }

                PanlityDemands[j] = Math.abs(min3 - min4);
                min3 = 99999999999.0;
                min4 = 99999999999.0;
                Counter2 = 0;
            }
            for (int i = 0; i < NumberOfDemands; i++) {

                System.out.println("Panelity demands " + PanlityDemands[i]);
            }
            for (int i = 0; i < NumberOfDemands; i++) {

                if (PanlityDemands[i] > maxPanlityDemands && Columndeleted[i] == -1) {
                    maxPanlityDemands = PanlityDemands[i];
                    IndexmaxPanilityDemands = i;
                }
            }
            System.out.println("max Panlity demands = : " + maxPanlityDemands);
            System.out.println(" Index of it is : " + IndexmaxPanilityDemands);


        } else {
            System.out.println(" No Dummy Here ");
        }
    }

    public void CalcuationVogels() {

        int CounterRowsDeleted = 0;
        int CounterColumnsDeleted = 0;

        while (Check() != true) {

            CounterColumnsDeleted = 0;
            CounterRowsDeleted = 0;

            CalculatePanlity();
            //  maxPanlityResources = 0;
            //  maxPanlityDemands = 0;
            if (maxPanlityResources >= maxPanlityDemands) {

                System.out.println("Now M P R > M p D");

                for (int i = IndexmaxPanilityResources; i < IndexmaxPanilityResources + 1; i++) {

                    for (int j = 0; j < NumberOfDemands; j++) {

                        if (Costs[i][j] <= MinCostChoosen_1 && Rowdeleted[i] == -1 && Columndeleted[j] == -1) {
                            MinCostChoosen_1 = Costs[i][j];
                            IndexMinCostChoosen_1 = j;
                        }
                    }

                    System.out.println("Min Cost Choosen is : " + MinCostChoosen_1);
                    System.out.println("Index of it is : " + IndexMinCostChoosen_1);

                    if (Demands[IndexMinCostChoosen_1] > Resources[IndexmaxPanilityResources]) {

                        Demands_Recources_Solution[IndexmaxPanilityResources][IndexMinCostChoosen_1] = Resources[IndexmaxPanilityResources];
                        Rowdeleted[IndexmaxPanilityResources] = 0;
                        Demands[IndexMinCostChoosen_1] -= Resources[IndexmaxPanilityResources];
                        Resources[IndexmaxPanilityResources] = 0;
                        System.out.println(" Server 1 Ok");

                    } else if (Demands[IndexMinCostChoosen_1] == Resources[IndexmaxPanilityResources]) {

                        Demands_Recources_Solution[IndexmaxPanilityResources][IndexMinCostChoosen_1] = Resources[IndexmaxPanilityResources];
                        Rowdeleted[IndexmaxPanilityResources] = 0;
                        Columndeleted[IndexMinCostChoosen_1] = 0;
                        Demands[IndexMinCostChoosen_1] = 0;
                        Resources[IndexmaxPanilityResources] = 0;
                        System.out.println(" Server 2 Ok");

                    } else if (Demands[IndexMinCostChoosen_1] < Resources[IndexmaxPanilityResources]) {

                        Demands_Recources_Solution[IndexmaxPanilityResources][IndexMinCostChoosen_1] = Demands[IndexMinCostChoosen_1];
                        Columndeleted[IndexMinCostChoosen_1] = 0;
                        Resources[IndexmaxPanilityResources] -= Demands[IndexMinCostChoosen_1];
                        Demands[IndexMinCostChoosen_1] = 0;

                    } else {
                        System.out.println(" error occured 1 ");
                    }
                }

                MinCostChoosen_1 = 9999999999999999.0;

            } else if (maxPanlityDemands > maxPanlityResources) {

                System.out.println("Now M P D > M p R");

                for (int i = IndexmaxPanilityDemands; i < IndexmaxPanilityDemands + 1; i++) {
                    for (int j = 0; j < Costs2[i].length; j++) {

                        if (Costs2[i][j] < MinCostChoosen_2 && Rowdeleted[j] == -1 && Columndeleted[i] == -1) {
                            MinCostChoosen_2 = Costs2[i][j];
                            IndexMinCostChoosen_2 = j;
                        }
                    }
                    System.out.println("Min Cost Choosen is : " + MinCostChoosen_2);
                    System.out.println("Index of it is : " + IndexMinCostChoosen_2);

                    if (Resources[IndexMinCostChoosen_2] > Demands[IndexmaxPanilityDemands]) {

                        Demands_Recources_Solution[IndexMinCostChoosen_2][IndexmaxPanilityDemands] = Demands[IndexmaxPanilityDemands];
                        Columndeleted[IndexmaxPanilityDemands] = 0;
                        Resources[IndexMinCostChoosen_2] -= Demands[IndexmaxPanilityDemands];
                        Demands[IndexmaxPanilityDemands] = 0;
                    } else if (Resources[IndexMinCostChoosen_2] == Demands[IndexmaxPanilityDemands]) {

                        Demands_Recources_Solution[IndexMinCostChoosen_2][IndexmaxPanilityDemands] = Demands[IndexmaxPanilityDemands];
                        Rowdeleted[IndexMinCostChoosen_2] = 0;
                        Columndeleted[IndexmaxPanilityDemands] = 0;
                        Demands[IndexmaxPanilityDemands] = 0;
                        Resources[IndexMinCostChoosen_2] = 0;
                        System.out.println(" Server 3 Ok");

                    } else if (Resources[IndexMinCostChoosen_2] < Demands[IndexmaxPanilityDemands]) {

                        Demands_Recources_Solution[IndexMinCostChoosen_2][IndexmaxPanilityDemands] = Resources[IndexMinCostChoosen_2];
                        Rowdeleted[IndexMinCostChoosen_2] = 0;
                        Demands[IndexmaxPanilityDemands] -= Resources[IndexMinCostChoosen_2];
                        Resources[IndexMinCostChoosen_2] = 0;
                        System.out.println(" Server 4 Ok");

                    } else {
                        System.out.println("error occured 2 ");
                    }
                }

                MinCostChoosen_2 = 9999999999999999999.0;

            } else {
                System.out.println(" error occured 3 ");
            }
            for (int i = 0; i < numberOfResources; i++) {

                if (Rowdeleted[i] == 0) {

                    CounterRowsDeleted++;
                    System.out.println("counter Columns deleted is : " + CounterColumnsDeleted);
                }
            }
            for (int i = 0; i < Demands_Recources_Solution.length; i++) {

                if (Columndeleted[i] == 0) {

                    CounterColumnsDeleted++;
                    System.out.println("counter Rows deleted is : " + CounterRowsDeleted);
                }
            }

            if (CounterRowsDeleted == (numberOfResources - 1) || CounterColumnsDeleted == (NumberOfDemands - 1)) {

                System.out.println(" do final result............................");
                Final = true;
                break;
            }

            for (int i = 0; i < Demands_Recources_Solution.length; i++) {
                for (int j = 0; j < Demands_Recources_Solution[i].length; j++) {

                    System.out.println(" Demand_resourse Solution of [" + (i) + "] ["
                            + (j) + "] is : " + Demands_Recources_Solution[i][j]);

                }
            }

            System.out.println("*****************Deleted********************");

            for (int i = 0; i < Rowdeleted.length; i++) {

                if (Rowdeleted[i] == 0) {
                    System.out.println(" The row deleted is " + (i + 1));
                }
            }
            for (int i = 0; i < Columndeleted.length; i++) {

                if (Columndeleted[i] == 0) {
                    System.out.println(" The column deleted is " + (i + 1));
                }
            }
            for (int i = 0; i < Resources.length; i++) {

                System.out.println(" Resource of " + (i + 1) + Resources[i]);
            }
            for (int i = 0; i < Demands.length; i++) {

                System.out.println(" Demand of " + (i + 1) + Demands[i]);
            }
        }

        if (Final == true) {

            if (CounterRowsDeleted == (numberOfResources - 1)) {

                int index1 = -1;

                for (int i = 0; i < numberOfResources; i++) {

                    if (Rowdeleted[i] == -1) {
                        index1 = i;
                        System.out.println("the last resource is : " + Resources[index1]);
                    }
                }

                for (int i = 0; i < NumberOfDemands; i++) {

                    if (Demands[i] >= 0) {

                        Demands_Recources_Solution[index1][i] += Demands[i];
                        Demands[i] = 0;
                    }

                }

            } else if (CounterColumnsDeleted == (numberOfResources - 1)) {

                int index2 = -1;

                for (int i = 0; i < NumberOfDemands; i++) {

                    if (Columndeleted[i] == -1) {

                        index2 = i;
                        System.out.println("The last demand is : " + Demands[index2]);
                    }
                }
                for (int i = 0; i < numberOfResources; i++) {

                    if (Resources[i] >= 0) {

                        Demands_Recources_Solution[i][index2] += Resources[i];
                        Resources[i] = 0;
                    }
                }

            }
        }

        for (int i = 0; i < Demands_Recources_Solution.length; i++) {
            for (int j = 0; j < Demands_Recources_Solution[i].length; j++) {

                System.out.println(" Demand_resourse Solution of [" + (i) + "] ["
                        + (j) + "] is : " + Demands_Recources_Solution[i][j]);

                if (Demands_Recources_Solution[i][j] != 0) {

                    frame.text_Solution[i][j].setText(Demands_Recources_Solution[i][j] + "");
                    frame.text_Solution[i][j].setFont(new Font(null, 10, 30));

                }
            }
        }
        System.out.println("finished");
    }

    public static void main(String[] args) {

        Vogel n1 = new Vogel();

        n1.CalcuationVogels();

    }
}
