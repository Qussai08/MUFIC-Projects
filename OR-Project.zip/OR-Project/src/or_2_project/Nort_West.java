package or_2_project;

import java.awt.Font;
//import javax.swing.JOptionPane;

public class Nort_West {

    int numberOfResources = GuiTransportation.numberOfResources, numberOfDemands = GuiTransportation.numberOfdemands;
    double demed[];
    double resource[];
    double element[][];
    FrameSolutionOfTransportation frame = new FrameSolutionOfTransportation();

    public Nort_West() {

     
        resource = new double[numberOfResources];
        demed = new double[numberOfDemands];
        element = new double[numberOfResources][numberOfDemands];
        resource = GuiTransportation.Resources;
        demed = GuiTransportation.Demands;
        

    }

    public void clalculation() {
        for (int row = 0; row < resource.length; row++) {
            for (int coulm = 0; coulm < demed.length; coulm++) {
                if (resource[row] >= demed[coulm] && !(resource[row] < 0 || demed[coulm] < 0)) {
                    element[row][coulm] = demed[coulm];
                    resource[row] -= element[row][coulm];
                    demed[coulm] -= element[row][coulm];
                } else if (demed[coulm] > resource[row] && !(resource[row] < 0 || demed[coulm] < 0)) {

                    element[row][coulm] = resource[row];
                    resource[row] -= element[row][coulm];
                    demed[coulm] -= element[row][coulm];
                }
            }
        
    }
    }
    public void display() {
        for (int i = 0; i < resource.length; i++) {
            for (int j = 0; j < demed.length; j++) {
                if (element[j][i] != 0) {
                    System.out.println(" the solution of " + (j + 1) + " " + (i+ 1) + " is : " + element[j][i]);
                    frame.text_Solution[j][i].setText(element[j][i] + "");
                    frame.text_Solution[j][i].setFont(new Font(null, 10, 30));

                } else {
                    System.out.println("x");
                }
            }
        }
    }

//    public static void main(String[] args) {
//
//        Nort_West m = new Nort_West();
//        m.clalculation();
//        m.display();
//
//
//    }
}
