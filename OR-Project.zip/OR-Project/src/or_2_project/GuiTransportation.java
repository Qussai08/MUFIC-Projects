package or_2_project;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class GuiTransportation extends JFrame {

    JButton b_north, b_min, b_vogel;
    JTextField[][] EnterData;
    JLabel l_Resources, l_Demands;
    JPanel panel;
    ImageIcon background;
    static int numberOfResources, numberOfdemands;
    static double[][] Costs;
    static double[] Resources;
    static double[] Demands;
    int counterY = 0;
    int counterX = 0;

    public GuiTransportation() {

        panel = (JPanel) new JFrame().getContentPane();
        background = new ImageIcon("transportation3.png");

        b_north = new JButton(" North west ");
        b_min = new JButton(" min way ");
        b_vogel = new JButton(" Vogel's ");
//******************************************************************************
        b_north.setBounds(5, 100, 120, 60);
        b_min.setBounds(5, 170, 120, 60);
        b_vogel.setBounds(5, 240, 120, 60);

//******************************************************************************
        panel.add(b_min);
        panel.add(b_north);
        panel.add(b_vogel);
//******************************************************************************
        String s = JOptionPane.showInputDialog(null, " please enter number of resources");
        numberOfResources = Integer.parseInt(s);
        String w = JOptionPane.showInputDialog(null, " please enter number of demands");
        numberOfdemands = Integer.parseInt(w);

        Costs = new double[numberOfResources][numberOfdemands];
        Resources = new double[numberOfResources];
        Demands = new double[numberOfdemands];


        EnterData = new JTextField[numberOfResources + 1][numberOfdemands + 1];

        l_Resources = new JLabel(" Resources");
        l_Demands = new JLabel("Demands");
        l_Resources.setForeground(Color.WHITE);
        l_Demands.setForeground(Color.WHITE);
        int X_Axis = 0;

        for (int i = 0; i < EnterData.length; i++) {
            for (int j = 0; j < EnterData[i].length; j++) {

                EnterData[i][j] = new JTextField();
                EnterData[i][j].setBounds(240 + counterX, 110 + counterY, 40, 40);

                counterX += 50;

                if (counterX == (numberOfdemands + 1) * 50) {
                    counterX = 0;
                    counterY += 50;
                }
                X_Axis = counterY;
                panel.add(l_Demands);
                panel.add(l_Resources);
            }
        }
        l_Resources.setBounds(210 + (45) * (numberOfdemands + 1), 35, 90, 90);
        l_Demands.setBounds(160, 35 + X_Axis, 90, 90);


        for (int i = 0; i < EnterData.length; i++) {
            for (int j = 0; j < EnterData[i].length; j++) {

                if (i == EnterData.length - 1 && j == EnterData[i].length - 1) {
                } else {
                    panel.add(EnterData[i][j]);
                }
            }
        }
        EnterData[numberOfResources][numberOfdemands].setText("0");

        b_north.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                TakeData();
                Nort_West n = new Nort_West();
                n.clalculation();
                n.display();

            }
        });
        b_min.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                TakeData();
                Min m = new Min();
                m.calculation();
                m.display();

            }
        });
        b_vogel.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                TakeData();
                Vogel v = new Vogel();
                v.CalcuationVogels();

            }
        });


        panel.add(new JLabel(background));
        add(panel);
        pack();
        setVisible(true);
        setLocationRelativeTo(null);
        setTitle("OR PROJECT");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

    }

    public void TakeData() {

        boolean flag = checkData();

        if (flag == true) {

            for (int i = 0; i < EnterData.length; i++) {
                for (int j = 0; j < EnterData[i].length; j++) {

                    if (i != EnterData.length - 1 && j != EnterData[i].length - 1) {

                        Costs[i][j] = Double.parseDouble(EnterData[i][j].getText());
                    }
                    if (j == EnterData[i].length - 1 && i < EnterData.length - 1) {

                        Resources[i] = Double.parseDouble(EnterData[i][j].getText());
                    }
                    if (i == EnterData.length - 1 && j < EnterData[i].length - 1) {

                        Demands[j] = Double.parseDouble(EnterData[i][j].getText());
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, " Please make sure of entering data");
        }

    }

    public boolean checkData() {

        boolean flag = true;

        for (int i = 0; i < EnterData.length; i++) {
            for (int j = 0; j < EnterData[i].length; j++) {

                if (EnterData[i][j].getText().equals("")) {

                    flag = false;
                }
            }
        }
        return flag;
    }

    public static void main(String[] args) {

        GuiTransportation obj = new GuiTransportation();
    }
}
