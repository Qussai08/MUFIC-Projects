package or_2_project;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.*;

public class frameStartProject extends JFrame {

    JButton buttonTransportation = new JButton(" Transportation");
    JButton buttonSimplix = new JButton(" Simplex");
    JLabel labelChoice = new JLabel(" Please choose project you want");
    JPanel panelLabel = new JPanel();
    JPanel panelbuttons = new JPanel();
    JPanel panel = new JPanel();

    public frameStartProject() {

        panelLabel.setLayout(new FlowLayout());
        panelLabel.setSize(370, 50);
        panelLabel.setLocation(0, 20);
        panelLabel.setBackground(Color.white);
        panelLabel.add(labelChoice);
//
//        panelbuttons.setLayout(new GridLayout(1,2));
//        panelbuttons.setSize(300, 50);
//        panelbuttons.setLocation(80, 85);
        buttonSimplix.setBounds(10, 40, 90, 50);
        buttonTransportation.setBounds(110, 60, 90, 50);
        panelbuttons.setBounds(0, 100, 400, 200);
        panelbuttons.setBackground(Color.red);
        panelbuttons.add(buttonSimplix);
        panelbuttons.add(buttonTransportation);


        add(panelLabel);
        add(panelbuttons);
        add(panel);

        setTitle(" Choose Project");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400,300);
        setLocationRelativeTo(null);
        setVisible(true);


    }

    public static void main(String[] args) {

        frameStartProject g1 = new frameStartProject();


    }
}
