package or_2_project;

import java.awt.Font;
import javax.swing.JOptionPane;

public class Min {

    int numberOfresources = GuiTransportation.numberOfResources;
    int numberOfDemands = GuiTransportation.numberOfdemands;
    double arrCost[][], elemnt[][];
    double[] demand, resource;
    FrameSolutionOfTransportation frame = new FrameSolutionOfTransportation();

    public Min() {

        arrCost = new double[numberOfresources][numberOfDemands];
        elemnt = new double[numberOfresources][numberOfDemands];
        demand = new double[numberOfDemands];
        resource = new double[numberOfresources];
        arrCost = GuiTransportation.Costs;
        demand = GuiTransportation.Demands;
        resource = GuiTransportation.Resources;

    }

    public int[] miniCost() {

        int[] bb = {-1, -1};

        double min = 0;
        for (int i = 0; i < arrCost.length; i++) {
            for (int j = 0; j < arrCost[0].length; j++) {
                if (arrCost[i][j] > 0) {
                    min = arrCost[i][j];
                    break;
                }
            }
        }
        int row = 0, coulm = 0;
        int[] aa = new int[2];
        boolean x = false;

        for (int i = 0; i < arrCost.length; i++) {
            for (int j = 0; j < arrCost[0].length; j++) {
                if (arrCost[i][j] <= min && arrCost[i][j] != 0) {

                    min = arrCost[i][j];
                    x = true;
                    aa[0] = i;
                    aa[1] = j;

                }
            }
        }

        if (x == false) {
            return bb;
        } else {
            return aa;
        }
    }

    public void display() {
        for (int i = 0; i < demand.length; i++) {
            for (int j = 0; j < demand.length; j++) {
                if (elemnt[i][j] != 0) {
                    System.out.println(elemnt[i][j]);
                    frame.text_Solution[i][j].setText(elemnt[i][j] + "");
                    frame.text_Solution[i][j].setFont(new Font(null, 10, 30));

                } else {
                    System.out.println("x");
                }
            }

        }

    }

    public void calculation() {
        int[] width = new int[2];


        int row = 0;
        int coulm = 0;
        //  display();
        width = miniCost();

        do {


            row = width[0];
            coulm = width[1];
            if (row != -1) {

                if (demand[row] >= resource[coulm] && !(demand[row] < 0 || resource[coulm] < 0)) {
                    elemnt[row][coulm] = resource[coulm];
                    demand[row] -= elemnt[row][coulm];
                    resource[coulm] -= elemnt[row][coulm];

                    int x = coulm;
                    for (int i = 0; i < demand.length; i++) {
                        arrCost[i][x] = 0;
                    }

                } else if (resource[coulm] > demand[row] && !(demand[row] < 0 || resource[coulm] < 0)) {

                    elemnt[row][coulm] = demand[row];
                    demand[row] -= elemnt[row][coulm];
                    resource[coulm] -= elemnt[row][coulm];

                    int x = row;
                    for (int i = 0; i < resource.length; i++) {
                        arrCost[x][i] = 0;
                    }
                }
            }

            width = miniCost();

            if (row == 2 && coulm == 1) {
                System.out.println("ok");
            }

        } while (row != -1);
    }

//    public static void main(String[] args) {
//
//        Min m = new Min();
//        //   m.insertDemed();
//        m.calculation();
//        // int[] x = new int[2];
////        x = m.miniCost();
////        System.out.println(x[0] + "" + x[1]);
//        m.display();
//    }
}
