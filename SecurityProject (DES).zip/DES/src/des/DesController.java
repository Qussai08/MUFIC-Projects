/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package des;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Font;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author hodam
 */
public class DesController implements Initializable {

    @FXML
    private TextArea inputArea;
    @FXML
    private Font x1;
    @FXML
    private TextField keyField;
    @FXML
    private RadioButton radioEncryption;
    @FXML
    private RadioButton radioDecryption;
    @FXML
    private TextArea outputArea;

    ToggleGroup radioGroup1 = new ToggleGroup();
    ToggleGroup radioGroup2 = new ToggleGroup();
    ToggleGroup radioGroup3 = new ToggleGroup();
    @FXML
    private Button runBtn;
    @FXML
    private Label inputLabel;
    @FXML
    private Label outputLabel;
    @FXML
    private Button exitBtn;

    DES algorithm = new DES();
    @FXML
    private RadioButton radioHex;
    @FXML
    private RadioButton radioChars;

    String output = "";
    @FXML
    private RadioButton keyHex;
    @FXML
    private RadioButton keyBin;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        radioEncryption.setToggleGroup(radioGroup1);
        radioDecryption.setToggleGroup(radioGroup1);
        radioEncryption.setSelected(true);

        radioHex.setToggleGroup(radioGroup2);
        radioChars.setToggleGroup(radioGroup2);
        radioHex.setSelected(true);

        keyHex.setToggleGroup(radioGroup3);
        keyBin.setToggleGroup(radioGroup3);
        keyHex.setSelected(true);

        inputArea.setPromptText("Please insert your plain text in normal alphabets");
        outputArea.setEditable(false);

        keyField.setPromptText("16-bit Hexadecimal Key");
    }

    @FXML
    private void run(ActionEvent event) {
        try {
        String input = inputArea.getText();
        String key = keyField.getText();
        if (radioGroup3.getSelectedToggle() == keyBin) {
            key = algorithm.BinToHex(key);
        }
        if (radioGroup1.getSelectedToggle() == radioEncryption) {
            output = algorithm.encryption(input, key);
        } else if (radioGroup1.getSelectedToggle() == radioDecryption) {
            output = algorithm.decryption(input, key);
        }
        if (radioGroup2.getSelectedToggle() == radioHex) {
            outputArea.setText(output);
        } else if (radioGroup2.getSelectedToggle() == radioChars) {
            String output1 = algorithm.HexToChar(output);
            outputArea.setText(output1);

        }
        } catch (Exception e) {
         JOptionPane.showMessageDialog(null, e.getMessage());

        }
    }

    @FXML
    private void selectDecryption(ActionEvent event
    ) {
        runBtn.setText("Decrypt");
        inputLabel.setText("Cipher Text :");
        outputLabel.setText("Plain Text :");
        inputArea.setText("");
        inputArea.setPromptText("Please insert your cipher text in hexadecimal");
    }

    @FXML
    private void selectEncryption(ActionEvent event
    ) {
        runBtn.setText("Encrypt");
        inputLabel.setText("Plain Text :");
        outputLabel.setText("Cipher Text :");
        inputArea.setText("");
        inputArea.setPromptText("Please insert your plain text in normal alphabets");

    }

    @FXML
    private void toExit(ActionEvent event
    ) {
        System.exit(0);
    }

    @FXML
    private void setHex(ActionEvent event
    ) {
        outputArea.setText(output);
    }

    @FXML
    private void setChars(ActionEvent event
    ) {
        outputArea.setText(algorithm.HexToChar(output));
    }

    @FXML
    private void keyHexAction(ActionEvent event
    ) {
        keyField.setPromptText("16-bit Hexadecimal Key");

    }

    @FXML
    private void keyBinAction(ActionEvent event
    ) {
        keyField.setPromptText("64-bit Binary Key");

    }

}
